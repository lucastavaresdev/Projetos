const express = require("express")
const usuarios = express.Router()
const cors = require('cors')
const jwt = require("jsonwebtoken")
const bcrypt = require('bcrypt')

const User = require("../models/User")
usuarios.use(cors())

process.env.SECRET_KEY = 'itechmeddsadsadsa'

usuarios.post('/registrar', (req, res) => {
    const hoje = new Date()
    const userData = {
        nome: req.body.nome,
        sexo: req.body.sexo,
        cadastro: req.body.cadastro,
        perfil: req.body.perfil,
        login: req.body.login,
        senha: req.body.senha,
        ativo: req.body.ativo,
        tipoUsuario: req.body.tipoUsuario,
        crm: req.body.crm,
        dataCadastro: hoje
    }

    User.findOne({
        where: {
            login: req.body.login
        }
    })
    .then(user => {
        if (!user) {
            bcrypt.hash(req.body.senha, 10, (err, hash) => {
                userData.senha = hash
                User.create(userData)
                    .then(user => {
                        res.json({ status: user.login + ' registrado' })
                    })
                    .catch(err => {
                        res.send('error: ' + err)
                    })
            })
        } else {
            res.json({ error: "Usuario ja existe" })
        }
    })
    .catch(err => {
        res.send('error: ' + err)
    })
})

usuarios.post('/login', (req, res) => {
    User.findOne({
        where: {
            login: req.body.login,
        }
    })
    .then(user => {
        if(user){
            console.log(req.body.senha)
            if(bcrypt.compareSync(req.body.senha, user.senha)) {
                let token = jwt.sign(user.dataValues, process.env.SECRET_KEY, {
                    expiresIn: 1440
                })
                res.send(token)
            }
        }else{
            res.status(400).send({error: err})
        }
    })
    .catch(err => {
        res.status(400).json({ error: err })
    })
})


//Selects



module.exports = usuarios