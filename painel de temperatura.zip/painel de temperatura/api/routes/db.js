const mysql = require('mysql');

function execQuery(query, res){
    const connection = mysql.createConnection({
      host     : 'itechbd.mysql.database.azure.com',
      port: '3306',
      user     : 'itechflow@itechbd',
      password : 'Itechm@ster_2018',
      database : 'umdi'
    });
  
    connection.query(query, function(error, results, fields){
        if(error) 
          res.json(error);
        else
          res.json(results);
           connection.end();
         console.log('executou!');
    });
  }


  module.exports = execQuery